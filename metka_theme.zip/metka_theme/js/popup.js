$(".sanastoTablesorter").dataTable( {
	"bJQueryUI": true,
	"sPaginationType": "full_numbers",
	"bLengthChange": false,
	"bFilter": true,
	"bSort": true,
	"bInfo": false,
	"bAutoWidth": false

} );
